This balloon is designed to mimic the look of the Undertale dialogue boxes. It's very simple and will look mostly the same for both characters. It does require the fonts Determination Mono and Determination Sans to look right though, so make sure you have them installed. If you don't have them, you can pick them up from here:

https://www.behance.net/gallery/31268855/Determination-Better-Undertale-Font 

And I'll include them both with the balloon.

For questions/troubleshooting etc, you can contact me at zarla.livejournal.com, zarla-s.tumblr.com, or zarla.dreamwidth.org. 


--------Version History

Ver 1.1 - Added font files for Determination Mono/Sans, Comic Sans UT, Papyrus UT, and Wingdings.
Ver 1.0 - Balloon Release